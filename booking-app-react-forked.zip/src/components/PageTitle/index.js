import "./styles.css";

const PageTitle = () => {
  return (
    <h1 className="PageTitle">
      Hotel Search
    </h1>
  );
};

export default PageTitle;
